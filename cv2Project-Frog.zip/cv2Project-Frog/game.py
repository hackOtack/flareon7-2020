import numpy as np
import time
import pyautogui
from PIL import Image, ImageOps, ImageGrab


start_x = 955
start_y = 542


class Game:

    def __init__(self, vision, controller):
        self.vision = vision
        self.controller = controller
        self.state = 'not started'

    def run(self):
        while True:
            self.vision.refresh_frame()
            if self.state == 'not started':
                self.log('starting the game')
                self.start_game()
                self.state = 'started'

            if self.can_duck():
                print("should DUCK!")
                self.wait_time()
                self.duck()
                self.state = 'ducked'
            elif self.can_jump():
                print("should JUMP!")
                self.wait_time()
                self.jump()
                self.state = 'jumpped'
            #elif self.state == 'jummped' or self.state == 'ducked':
                #print("wait after jump")
                #time.sleep(0.04)

    def can_duck(self):
        matches = self.vision.find_template('M')
        res =  np.shape(matches)[1] >= 1
        return res

    def can_jump(self):        
        matches = self.vision.find_template('F')
        res_f = np.shape(matches)[1] >= 1
        if(res_f):
            return True
        matches = self.vision.find_template('T')
        res_t = np.shape(matches)[1] >= 1
        if(res_t):
            return True
        matches = self.vision.find_template('S')
        res_s = np.shape(matches)[1] >= 1
        if(res_s):
            return True
        return False

        
    def wait_time(self):
        while(True):
            im = self.screenGrab()
            distance = 0
            for i in range (28,490):
                try:
                    if im.getpixel((i, 290)) != (0, 21, 27):
                       distance = i - 28
                       break
                except:
                    print(i)
            if distance <  153:
               print("no wait")
               return 0
        '''    
        elif distance < 200:
           print("wait 200")
           return 0.05
        elif distance < 300:
           print("wait 300")
           return 0.08
        else:
           print("too far")
           return 0.2
       '''

    def screenGrab(self):
        box = (419, 349, 917, 709)
        im = ImageGrab.grab(box)
        #im.save('full_snap__.png', 'PNG')
        #data = im.load()
        #pyautogui.screenshot('myscreen_.png' , region=(x_pad+1,y_pad+1, x_pad+1280, y_pad+751))
        return im     

    def duck(self):
        #self.controller(2
        self.hold_key('down', 0.6)
    
    def jump(self):
        #self.controller()
        #time.sleep(0.2)
        pyautogui.press('up')

    def start_game(self):
        pyautogui.click(start_x, start_y)
        time.sleep(0.1)
           
    def hold_key(self, key, hold_time):
        start = time.time()
        while time.time() - start < hold_time:
            pyautogui.keyDown(key)
        pyautogui.keyUp(key)

    def long_press_duck(self):
        pyautogui.keyDown('down')
            
    def log(self, text):
        print('[%s] %s' % (time.strftime('%H:%M:%S'), text))    
############################################################################################

