from unittest import TestCase
from unittest.mock import Mock
from vision import Vision
import numpy as np
import unittest

class VisionTest(TestCase):

    def setUp(self):
        self.vision = Vision()
        
        
    def test_finds_mblock_1(self):
        screenshot = self.vision.get_image('screens/test_1.png')
        match = self.vision.find_template('block_corner', screenshot)
        print(np.shape(match))

    def test_finds_mblock_2(self):
        screenshot = self.vision.get_image('screens/test_2.png')
        match = self.vision.find_template('M', screenshot)
        print(np.shape(match))
        #self.assertEqual(np.shape(match)[1], 1)
        
    def test_finds_mblock_3(self):
        screenshot = self.vision.get_image('screens/test_4.png')
        match = self.vision.find_template('M', screenshot)
        print(np.shape(match))
        #self.assertEqual(np.shape(match)[1], 1)

        
    def test_finds_mblock_4(self):
        screenshot = self.vision.get_image('screens/test_5.png')
        match = self.vision.find_template('block_corner', screenshot)
        print(np.shape(match))
        #self.assertEqual(np.shape(match)[1], 0)
        

    def test_finds_mblock_5(self):
        screenshot = self.vision.get_image('screens/test_9.png')
        match = self.vision.find_template('M_small', screenshot, threshold=0.5)
        print(np.shape(match))
        
    def test_finds_mblock_6(self):
        screenshot = self.vision.get_image('screens/test_9.png')
        match = self.vision.find_template('M_small', screenshot, threshold=0.5)
        print(np.shape(match))

    def test_finds_mblock_7(self):
        screenshot = self.vision.get_image('sct-mon-3.png')
        match = self.vision.find_template('M_small', screenshot, threshold=0.9)
        print(np.shape(match))
        #self.assertEqual(np.shape(match)[1], 1)


if __name__ == '__main__':
    unittest.main()
