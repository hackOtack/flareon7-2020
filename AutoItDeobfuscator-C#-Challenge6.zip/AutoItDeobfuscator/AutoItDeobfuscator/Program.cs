﻿using System;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace AutoItDeobfuscator
{
	class Program
	{
		static Dictionary<string, string> variables =
				new Dictionary<string, string>();
		static string[] lines;
		static void Main(string[] args)
		{
			Console.WriteLine("Wellcome to Challenge 6!");
			// read script file into lines
			lines = File.ReadAllLines("C:\\Users\\REM\\Desktop\\flare\\6\\script_deobfuscated.au3");

			// string line = "Global $flavekolca = Number(\" 0 \"), $flerqqjbmh = Number(\" 1 \"), $flowfrckmw = Number(\" 0 \"), $flmxugfnde = Number(\" 0 \"), $flvjxcqxyn = Number(\" 2 \"), $flddxnmrkh = Number(\" 0 \"), $flroseeflv = Number(\" 1 \"), $flpgrglpzm = Number(\" 0 \"), $flvzrkqwyg = Number(\" 0 \"), $flyvormnqr = Number(\" 0 \"), $flvthbrbxy = Number(\" 1 \"), $flxttxkikw = Number(\" 0 \"), $flgjmycrvw = Number(\" 1 \"), $flceujxgse = Number(\" 0 \"), $flhptoijin = Number(\" 0 \"), $flrzplgfoe = Number(\" 0 \"), $fliboupial = Number(\" 0 \"), $flidavtpzc = Number(\" 1 \"), $floeysmnkq = Number(\" 1 \"), $flaibuhicd = Number(\" 0 \"), $flekmapulu = Number(\" 1 \")";
			// string[] lines_2 = new string[1];
			//lines_2[0] = line;
			//Number();
			//Replace_Variables(); //done
			//OS_Replace(); // done

			//Replace_String_Mid();

			decoder();	
			//File.WriteAllLines("C:\\Users\\REM\\Desktop\\flare\\6\\script_deobfuscated.au3", lines);
		}

		static void decoder() {

			byte[] image = File.ReadAllBytes("C:\\Users\\REM\\Desktop\\flare\\6\\sprite.bmp");
			byte[] first_few = new byte[54];
			for (int i = 0; i < 54; i++) {
				first_few[i] = image[i];
			}
			ASCIIEncoding ascii = new ASCIIEncoding();
			//Console.WriteLine(ascii.GetString(first_few));
			string com_name = "FLAREERALF"; //DESKTOP-2C3IQHO
			byte[] computer_name = Encoding.ASCII.GetBytes(com_name);
			int index = 54; //1;
			string result = "";
			//Console.WriteLine(1 & 41);
			for (int index_2 = 0; index_2 < computer_name.Length; index_2++) {
				int byte_val = computer_name[index_2];
				int original_val = byte_val; 
				for (int index_3 = 6; index_3 > 0; index_3--)
				{
					int temp = image[index];
					//Console.WriteLine("image:" + temp.ToString());
					byte_val += (temp & 1) << (1 * index_3);
					index += 1;
				}
				int c = byte_val - original_val; 
				Console.WriteLine(c);
				result += (char)(byte_val >> 1) + ((byte_val & 1) << 7);
			}
			//Console.WriteLine(result);
			//Console.WriteLine("\n" + result);
		}
		static void File_Installer() {
		}

		static void Replace_String_Mid() {
			//String_Mid("6b65726e656c33322e646c6c")
			Regex regex3 = new Regex(@"(Hex_to_String\(""(\w*)""\))"); //@"\$(\w*)\s\=\sNumber\(""\s(\d*)\s""\)"
			for (int i = 0; i < lines.Length; i++)
			{
				if (i == 461) {
					Console.WriteLine("pause");
				}
				Match m3 = regex3.Match(lines[i]);
				while (m3.Success)
				{
					string hex_string = m3.Groups[2].Value.ToString();
					string value = String_Mid(hex_string);
					lines[i] = regex3.Replace(lines[i], String.Format("\"{0}\"", value), 1);
					m3 = m3.NextMatch();
				}
			}
		}
		static string String_Mid(string input) {
			string output = ""; 
			for (int index = 0; index < input.Length-1; index+=2 ) {
				string sub = input.Substring(index, 2);
				long value = Int64.Parse(sub, System.Globalization.NumberStyles.HexNumber); 
				output += (char)(value);
			}
			return output;

		}


		static void OS_Replace() {
			string dlit = "7374727563743b75696e7420626653697a653b75696e7420626652657365727665643b75696e742062664f6666426974733b" +
					"75696e7420626953697a653b696e7420626957696474683b696e742062694865696768743b7573686f7274206269506c616e" +
					"65733b7573686f7274206269426974436f756e743b75696e74206269436f6d7072657373696f6e3b75696e7420626953697a" +
					"65496d6167653b696e742062695850656c735065724d657465723b696e742062695950656c735065724d657465723b75696e" +
					"74206269436c72557365643b75696e74206269436c72496d706f7274616e743b656e647374727563743b4FD5$626653697a6" +
					"54FD5$626652657365727665644FD5$62664f6666426974734FD5$626953697a654FD5$626957696474684FD5$6269486569" +
					"6768744FD5$6269506c616e65734FD5$6269426974436f756e744FD5$6269436f6d7072657373696f6e4FD5$626953697a65" +
					"496d6167654FD5$62695850656c735065724d657465724FD5$62695950656c735065724d657465724FD5$6269436c7255736" +
					"5644FD5$6269436c72496d706f7274616e744FD5$7374727563743b4FD5$627974655b4FD5$5d3b4FD5$656e647374727563" +
					"744FD5$4FD5$2e626d704FD5$5c4FD5$2e646c6c4FD5$7374727563743b64776f72643b636861725b313032345d3b656e647" +
					"374727563744FD5$6b65726e656c33322e646c6c4FD5$696e744FD5$476574436f6d70757465724e616d65414FD5$7074724" +
					"FD5$436f6465497420506c7573214FD5$7374727563743b627974655b4FD5$5d3b656e647374727563744FD5$73747275637" +
					"43b627974655b35345d3b627974655b4FD5$7374727563743b7074723b7074723b64776f72643b627974655b33325d3b656e" +
					"647374727563744FD5$61647661706933322e646c6c4FD5$437279707441637175697265436f6e74657874414FD5$64776f7" +
					"2644FD5$4372797074437265617465486173684FD5$437279707448617368446174614FD5$7374727563742a4FD5$4372797" +
					"07447657448617368506172616d4FD5$30784FD5$30383032304FD5$30303031304FD5$36363030304FD5$30323030304FD5" +
					"$303030304FD5$43443442334FD5$32433635304FD5$43463231424FD5$44413138344FD5$44383931334FD5$45364639324" +
					"FD5$30413337414FD5$34463339364FD5$33373336434FD5$30343243344FD5$35394541304FD5$37423739454FD5$413434" +
					"33464FD5$46443138394FD5$38424145344FD5$39423131354FD5$46364342314FD5$45324137434FD5$31414233434FD5$3" +
					"4433235364FD5$31324135314FD5$39303335464FD5$31384642334FD5$42313735324FD5$38423341454FD5$43414633444" +
					"FD5$34383045394FD5$38424638414FD5$36333544414FD5$46393734454FD5$30303133354FD5$33354432334FD5$314534" +
					"42374FD5$35423243334FD5$38423830344FD5$43374145344FD5$44323636414FD5$33374233364FD5$46324335354FD5$3" +
					"5424633414FD5$39454136414FD5$35384243384FD5$46393036434FD5$43363635454FD5$41453243454FD5$36304632434" +
					"FD5$44453338464FD5$44333032364FD5$39434334434FD5$45354242304FD5$39303437324FD5$46463942444FD5$323646" +
					"39314FD5$31394238434FD5$34383446454FD5$36394542394FD5$33344634334FD5$46454544454FD5$44434542414FD5$3" +
					"7393134364FD5$30383139464FD5$42323146314FD5$30463833324FD5$42324135444FD5$34443737324FD5$44423132434" +
					"FD5$33424544394FD5$34374636464FD5$37303641454FD5$34343131414FD5$35324FD5$7374727563743b7074723b70747" +
					"23b64776f72643b627974655b383139325d3b627974655b4FD5$5d3b64776f72643b656e647374727563744FD5$437279707" +
					"4496d706f72744b65794FD5$4372797074446563727970744FD5$464c4152454FD5$4552414c464FD5$43727970744465737" +
					"4726f794b65794FD5$437279707452656c65617365436f6e746578744FD5$437279707444657374726f79486173684FD5$73" +
					"74727563743b7074723b7074723b64776f72643b627974655b31365d3b656e647374727563744FD5$7374727563743b64776" +
					"f72643b64776f72643b64776f72643b64776f72643b64776f72643b627974655b3132385d3b656e647374727563744FD5$47" +
					"657456657273696f6e4578414FD5$456e746572207465787420746f20656e636f64654FD5$43616e2068617a20636f64653f" +
					"4FD5$4FD5$48656c704FD5$41626f757420436f6465497420506c7573214FD5$7374727563743b64776f72643b64776f7264" +
					"3b627974655b333931385d3b656e647374727563744FD5$696e743a636465636c4FD5$6a75737447656e6572617465515253" +
					"796d626f6c4FD5$7374724FD5$6a757374436f6e76657274515253796d626f6c546f4269746d6170506978656c734FD5$546" +
					"869732070726f6772616d2067656e65726174657320515220636f646573207573696e6720515220436f64652047656e65726" +
					"1746f72202868747470733a2f2f7777772e6e6179756b692e696f2f706167652f71722d636f64652d67656e657261746f722" +
					"d6c6962726172792920646576656c6f706564206279204e6179756b692e204FD5$515220436f64652047656e657261746f72" +
					"20697320617661696c61626c65206f6e20476974487562202868747470733a2f2f6769746875622e636f6d2f6e6179756b69" +
					"2f51522d436f64652d67656e657261746f722920616e64206f70656e2d736f757263656420756e6465722074686520666f6c" +
					"6c6f77696e67207065726d697373697665204d4954204c6963656e7365202868747470733a2f2f6769746875622e636f6d2f" +
					"6e6179756b692f51522d436f64652d67656e657261746f72236c6963656e7365293a4FD5$436f7079726967687420c2a9203" +
					"23032302050726f6a656374204e6179756b692e20284d4954204c6963656e7365294FD5$68747470733a2f2f7777772e6e61" +
					"79756b692e696f2f706167652f71722d636f64652d67656e657261746f722d6c6962726172794FD5$5065726d697373696f6" +
					"e20697320686572656279206772616e7465642c2066726565206f66206368617267652c20746f20616e7920706572736f6e2" +
					"06f627461696e696e67206120636f7079206f66207468697320736f66747761726520616e64206173736f636961746564206" +
					"46f63756d656e746174696f6e2066696c6573202874686520536f667477617265292c20746f206465616c20696e207468652" +
					"0536f66747761726520776974686f7574207265737472696374696f6e2c20696e636c7564696e6720776974686f7574206c6" +
					"96d69746174696f6e207468652072696768747320746f207573652c20636f70792c206d6f646966792c206d657267652c207" +
					"075626c6973682c20646973747269627574652c207375626c6963656e73652c20616e642f6f722073656c6c20636f7069657" +
					"3206f662074686520536f6674776172652c20616e6420746f207065726d697420706572736f6e7320746f2077686f6d20746" +
					"86520536f667477617265206973206675726e697368656420746f20646f20736f2c207375626a65637420746f20746865206" +
					"66f6c6c6f77696e6720636f6e646974696f6e733a4FD5$312e205468652061626f766520636f70797269676874206e6f7469" +
					"636520616e642074686973207065726d697373696f6e206e6f74696365207368616c6c20626520696e636c7564656420696e" +
					"20616c6c20636f70696573206f72207375627374616e7469616c20706f7274696f6e73206f662074686520536f6674776172" +
					"652e4FD5$322e2054686520536f6674776172652069732070726f76696465642061732069732c20776974686f75742077617" +
					"272616e7479206f6620616e79206b696e642c2065787072657373206f7220696d706c6965642c20696e636c7564696e67206" +
					"27574206e6f74206c696d6974656420746f207468652077617272616e74696573206f66206d65726368616e746162696c697" +
					"4792c206669746e65737320666f72206120706172746963756c617220707572706f736520616e64206e6f6e696e6672696e6" +
					"7656d656e742e20496e206e6f206576656e74207368616c6c2074686520617574686f7273206f7220636f707972696768742" +
					"0686f6c64657273206265206c6961626c6520666f7220616e7920636c61696d2c2064616d61676573206f72206f746865722" +
					"06c696162696c6974792c207768657468657220696e20616e20616374696f6e206f6620636f6e74726163742c20746f72742" +
					"06f72206f74686572776973652c2061726973696e672066726f6d2c206f7574206f66206f7220696e20636f6e6e656374696" +
					"f6e20776974682074686520536f667477617265206f722074686520757365206f72206f74686572206465616c696e6773206" +
					"96e2074686520536f6674776172652e4FD5$7374727563743b7573686f72743b656e647374727563744FD5$7374727563743" +
					"b627974653b627974653b627974653b656e647374727563744FD5$43726561746546696c654FD5$75696e744FD5$53657446" +
					"696c65506f696e7465724FD5$6c6f6e674FD5$577269746546696c654FD5$7374727563743b64776f72643b656e647374727" +
					"563744FD5$5265616446696c654FD5$436c6f736548616e646c654FD5$44656c65746546696c65414FD5$47657446696c655" +
					"3697a65";
			string[] os = dlit.Split("4FD5$");

			Regex regex3 = new Regex(@"(\$os\[(\d*)\])"); //@"\$(\w*)\s\=\sNumber\(""\s(\d*)\s""\)"
			for (int i = 0; i < lines.Length; i++)
			{
				Match m3 = regex3.Match(lines[i]);
				while (m3.Success)
				{
					string index = m3.Groups[2].Value.ToString();
					string value = os[Int64.Parse(index) -1 ];
					lines[i] = regex3.Replace(lines[i], String.Format("\"{0}\"", value), 1);
					m3 = m3.NextMatch();
				}
			}
		}


		static void Replace_Variables() {
            foreach (KeyValuePair<string, string> entry in variables)
            {
                for (int i = 160; i < lines.Length; i++) {
                    lines[i] = lines[i].Replace(entry.Key, entry.Value);
                }
                
            }
        }
        static void Number() {
            Regex regex3 = new Regex(@"\$(\w*)\s\=\sNumber\(""\s(\d*)\s""\)"); //@"\$(\w*)\s\=\sNumber\(""\s(\d*)\s""\)"
            for (int i = 0; i < lines.Length; i++)
            {
                Match m3 = regex3.Match(lines[i]);
                while (m3.Success)
                {
                    string var_name = m3.Groups[1].Value.ToString();
                    string value = m3.Groups[2].Value.ToString();
                    lines[i] = regex3.Replace(lines[i], String.Format("${0} = {1}", var_name, value), 1);
                    variables.Add("$"+ var_name, value);
                    m3 = m3.NextMatch();
                }
            }
            
        }

        static string[] StringLen(string[] lines) {
            Regex regex3 = new Regex(@"StringLen\(\""([A-Za-z]+)\""\)");
            for (int i = 0; i < lines.Length; i++)
            {
                Match m3 = regex3.Match(lines[i]);
                while (m3.Success)
                {
                    string expr1 = m3.Groups[1].Value.ToString();
                    Console.WriteLine("before stringlen: " + lines[i]);
                    lines[i] = regex3.Replace(lines[i], String.Format("{0}", expr1.Length), 1);
                    Console.WriteLine("after stringlen: " + lines[i]);
                    m3 = m3.NextMatch();
                }
            }
            return lines;

        }
        static void SeduRandom() { 
        }
        static void MathEvaluator()
        {
            //
        }

    }
}
